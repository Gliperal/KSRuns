How to use:

Unzip the contents of the zip file somewhere. Running from a zip will likely cause problems.

Run the file MachineRandomizer.bat. This will open a command prompt window. If it immediately closes, ensure that you have java installed and try again.

Follow the instructions in the window. When completed it will create four files:

	- DefaultSavegame.ini
	- Map.bin
	- World.ini

	- spoiler.txt

The first three files need to replace the existing files in:

	[your KS folder]/Worlds/Nifflas - The Machine/

Then launch Knytt Stories.exe (or your mod of choice) and load "The Machine" as normal.

The previous copies of those three files can be backed up elsewhere and then restored at any time.

The fourth file is a spoiler document that contains information about the item locations and an order in which it is theoretically possible to collect them.
