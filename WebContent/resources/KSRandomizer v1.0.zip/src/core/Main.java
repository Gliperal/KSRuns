package core;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import org.stackoverflowusers.file.WindowsShortcut;

import map.KSMap;

public class Main
{
	public static void main(String[] args)
	{
		// Get user input
		Scanner input = new Scanner(System.in);
		
		// Do everything in a sub method, so if an error gets free we can catch it before the program exits
		try
		{
			if (args.length > 0 && args[0].equals("restore"))
				restoreMain(input);
			else
				randoMain(input);
		} catch(Exception e)
		{
			e.printStackTrace();
		}
		UserInput.waitForEnter(input, "Press enter to exit.");
	}
	
	public static void randoMain(Scanner input)
	{
		// Load Knytt Stories location
		System.out.println("Loading Knytt Stories directory...");
		Path ksDir = loadKSDirectory();
		if (ksDir == null)
		{
			System.out.println("Unable to locate Knytt Stories directory.");
			return;
		}
		
		// Load object classes
		ObjectClassesFile classData;
		try
		{
			classData = loadObjectClasses();
		} catch (Exception e)
		{
			System.out.println(e.getMessage());
			return;
		}
		
		// Specify world
		Path worldFolder = getWorld(input, ksDir);
		if (worldFolder == null)
			return;
		System.out.println("World specified: " + worldFolder.getFileName());
		
		// Load map file
		System.out.println("Loading map file...");
		Path mapFile = worldFolder.resolve("Map.bin");
		if (!Files.exists(mapFile))
		{
			System.out.println("Error: Unable to locate file " + mapFile);
			return;
		}
		
		// Make sure the map is backed up (the backup is also the file we'll be reading in)
		Path originalMap = worldFolder.resolve("MapBackup.rando.bin");
		if (!Files.exists(originalMap))
		{
			try
			{
				Files.copy(mapFile, originalMap);
			} catch (IOException e)
			{
				if (UserInput.getBooleanInput(input, "Unable to make a backup of the map file. The original map will be overwritten. Are you sure you wish to continue?"))
					originalMap = mapFile;
				else
					return;
			}
		}
		
		// Get various things from the user
		long seed = UserInput.getSeedInput(input, "Enter seed or leave blank for random.");
		Random rand = new Random(seed);
		if (UserInput.getBooleanInput(input, "Would you like to see the object groups that are available for randomizing? [Y/N]"))
		{
			System.out.println("Randomizable groups:");
			classData.tabPrintClasses();
		}
		RandoKey randoKey = UserInput.getRandoKeyInput(input, "Enter a key for the randomization classes (leave blank if unsure).", classData);
		int randoType = UserInput.getCharInput(input, "Enter type of randomization (leave blank if unsure).\n\t0: Permute\n\t1: Shuffle\n\t2: Transform\n\t3: True random", new char[] {'0', '1', '2', '3'}, '0') - '0';
		
		// Do the thing
		UserInput.waitForEnter(input, "Press enter to begin.");
		
		// Load map
		KSMap map;
		try
		{
			map = new KSMap(originalMap);
		} catch (NoSuchFileException e)
		{
			System.out.println("Error: Unable to open file " + mapFile);
			return;
		} catch (IOException e)
		{
			System.out.println("Error: IOException reading file " + mapFile);
			return;
		} catch (Exception e)
		{
			System.out.println("Error parsing map file: " + e.getMessage());
			return;
		}
		
		// Begin randomization
		System.out.println("Randomizing...");
		
		// Randomize objects
		switch(randoType)
		{
		case 1:
			// SHUFFLE
			// Collect all the relevant objects in order
			ObjectShuffle shuffle = new ObjectShuffle(randoKey);
			map.populateShuffle(shuffle);
			// Shuffle those objects
			shuffle.generateShuffle(rand);
			// Randomize the map by walking through the objects in the exact same order as before
			map.shuffle(shuffle);
			break;
		case 0:
			// PERMUTE
			// Collect all the relevant objects
			ObjectClass mapObjects = map.allObjects();
			mapObjects.sort();
			// Trim RandoKey down to only use those objects
			randoKey.restrict(mapObjects);
			// Continue as with transform
		case 2:
			// TRANSFORM
			// Seed the key
			randoKey.seed(rand);
			// Then go screen by screen
			map.randomize(randoKey);
			break;
		case 3:
			// TRUE RANDOM
			// No seeeding or anything required
			map.randomize(randoKey, rand);
			break;
		}
		
		// Randomize music
		map.randomizeMusic(rand);
		
		// Save map
		System.out.println("Saving...");
		try
		{
			map.saveToFile(mapFile);
		} catch (NoSuchFileException e)
		{
			System.out.println("Error: Unable to open file " + mapFile);
			return;
		} catch (IOException e)
		{
			System.out.println("Error: IOException writing to file " + mapFile);
			return;
		} catch (Exception e)
		{
			System.out.println("Error writing screen data: " + e.getMessage());
			return;
		}
		System.out.println("Saved successfully.");
	}
	
	private static boolean isKSDirectory(Path ksDir)
	{
		if (!Files.isDirectory(ksDir))
			return false;
		return
				Files.exists(ksDir.resolve("Knytt Stories.exe")) ||
				Files.exists(ksDir.resolve("Knytt Stories Plus.exe")) ||
				Files.exists(ksDir.resolve("knytt stories ex.exe")) ||
				Files.exists(ksDir.resolve("Knytt Stories Speedrun Edition 0.2.2.exe")) ||
				Files.exists(ksDir.resolve("Knytt Stories Speedrun Edition 0.3.1.exe"));
	}
	
	private static Path loadKSDirectory()
	{
		Path ksDir;
		Path workingDir = Paths.get(System.getProperty("user.dir"));

		// If the jar is being run from a subfolder of the KS directory
		System.out.print("Checking local files...");
		ksDir = workingDir.getParent();
		if (isKSDirectory(ksDir))
		{
			System.out.println(" Yes.");
			return ksDir;
		}
		System.out.println(" No.");
		
		// If there is a symbolic link in the working directory called "KS"
		System.out.print("Checking for a KS symbolic link...");
		ksDir = workingDir.resolve("KS");
		if (isKSDirectory(ksDir))
		{
			System.out.println(" Yes.");
			return ksDir;
		}
		System.out.println(" No.");
		
		// If there is a Windows link in the working directory called "KS"
		System.out.print("Checking for a KS.lnk Windows link...");
		ksDir = workingDir.resolve("KS.lnk");
		if (Files.exists(ksDir))
		{
			try
			{
				WindowsShortcut shortcut = new WindowsShortcut(ksDir.toFile());
				ksDir = Paths.get(shortcut.getRealFilename());
				if (isKSDirectory(ksDir))
				{
					System.out.println(" Yes.");
					return ksDir;
				}
			} catch (Exception e) {}
		}
		System.out.println(" No.");
		
		// If there is a text file in the working directory called KS.txt, containing the Knytt Stories directory
		System.out.print("Checking in KS.txt...");
		Path ksTxt = workingDir.resolve("KS.txt");
		if (Files.exists(ksTxt))
		{
			try
			{
				BufferedReader br = Files.newBufferedReader(ksTxt);
				String line = br.readLine().trim();
				ksDir = Paths.get(line);
				if (isKSDirectory(ksDir))
				{
					System.out.println(" Yes.");
					return ksDir;
				}
			} catch (IOException e) {}
		}
		System.out.println(" No.");
		
		return null;
	}
	
	private static ObjectClassesFile loadObjectClasses() throws Exception
	{
		// Load object classes file
		System.out.println("Loading object classes file...");
		Path ocFile = Paths.get("resources", "ObjectClasses.txt");
		if (!Files.exists(ocFile))
			throw new Exception("Unable to open resources/ObjectClasses.txt.");
		
		// Load object classes
		try
		{
			return new ObjectClassesFile(ocFile);
		} catch (IOException e)
		{
			throw new Exception("IOException reading from resources/ObjectClasses.txt.");
		} catch (Exception e)
		{
			throw new Exception("Failed to parse resources/ObjectClasses.txt:\n" + e.getMessage());
		}
	}
	
	private static Path getWorld(Scanner input, Path ksDir)
	{
		// Load worlds directory
		Path worldsDir = ksDir.resolve("Worlds");
		if (!Files.exists(worldsDir))
		{
			System.out.println("Missing Worlds directory.");
			return null;
		}
		
		// Collect worlds
		ArrayList<Path> worlds = new ArrayList<Path>();
		ArrayList<String> worldStrings = new ArrayList<String>();
		try
		{
			for (Path world : Files.newDirectoryStream(worldsDir))
			{
				if (!Files.isDirectory(world))
					continue;
				worlds.add(world);
				worldStrings.add(world.getFileName().toString());
			}
		} catch (IOException e)
		{
			System.out.println("IOException loading worlds.");
			return null;
		}
		
		// Get user choice
		int worldID = UserInput.getInputFromList(input, "Select the world to randomize", worldStrings);
		return worlds.get(worldID);
	}
	
	private static void restoreMain(Scanner input)
	{
		// Confirm
		if (!UserInput.getBooleanInput(input, "This will restore all your randomized levels to their original states. Are you sure you wish to continue? [Y/N]"))
			return;
		
		// Load Knytt Stories location
		System.out.println("Loading Knytt Stories directory...");
		Path ksDir = loadKSDirectory();
		if (ksDir == null)
		{
			System.out.println("Unable to locate Knytt Stories directory.");
			return;
		}
		
		// Load worlds directory
		Path worldsDir = ksDir.resolve("Worlds");
		if (!Files.exists(worldsDir))
		{
			System.out.println("Missing Worlds directory.");
			return;
		}
		
		// Iterate over the worlds
		ArrayList<String> restoredWorlds = new ArrayList<String>();
		ArrayList<String> failedWorlds = new ArrayList<String>();
		try
		{
			for (Path world : Files.newDirectoryStream(worldsDir))
			{
				if (!Files.isDirectory(world))
					continue;
				// If the world contains a rando backup file, attempt to restore it
				Path originalMap = world.resolve("MapBackup.rando.bin");
				if (Files.exists(originalMap))
				{
					Path mapLocation = world.resolve("Map.bin");
					try
					{
						// Successfully restored map
						Files.move(originalMap, mapLocation, StandardCopyOption.REPLACE_EXISTING);
						restoredWorlds.add(world.getFileName().toString());
					}
					catch(IOException e)
					{
						// Failed to restore map
						failedWorlds.add(world.getFileName().toString());
					}
				}
			}
		} catch (IOException e)
		{
			System.out.println("IOException loading worlds.");
			return;
		}
		
		// Status
		if (!restoredWorlds.isEmpty())
		{
			System.out.println("The following worlds were resotred correctly:");
			for (String w : restoredWorlds)
				System.out.println(w);
		}
		if (!failedWorlds.isEmpty())
		{
			System.out.println("The following worlds failed to restore:");
			for (String w : failedWorlds)
				System.out.println(w);
		}
		if (restoredWorlds.isEmpty() && failedWorlds.isEmpty())
			System.out.println("Found nothing to restore.");
	}
}
