package map;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.io.IOUtils;

import core.ObjectClass;
import core.ObjectShuffle;
import core.RandoKey;

public class KSMap
{
	// The byte sequence 0 -66 11 0 0 denotes end of header
	public static final String endOfHeader = "\u0000\uFFBE\u000B\u0000\u0000";
	private ArrayList<Screen> screens;
	
	public KSMap()
	{
		screens = new ArrayList<Screen>();
	}
	
	private static String readScreenHeader(GZIPInputStream gis) throws IOException
	{
		byte[] buffer = new byte[1];
		int bytesRead;
		String header = "";
		while (true)
		{
			bytesRead = gis.read(buffer);
			if (bytesRead == -1)
				return null;
			header += (char) buffer[0];
			if (header.endsWith(endOfHeader))
				break;
			if (header.length() > 20) // No header should realistically be this long
				return header;
		}
		return header.substring(0, header.length() - 5);
	}
	
	public KSMap(Path mapFile) throws Exception
	{
		screens = new ArrayList<Screen>();
		
		// Setup GZip for map reading
		InputStream is = Files.newInputStream(mapFile);
		byte[] ba = IOUtils.toByteArray(is);
		ByteArrayInputStream bis = new ByteArrayInputStream(ba);
		GZIPInputStream gis = new GZIPInputStream(bis);
		
		// Read map data, one screen at a time
		String header;
		byte[] screenData = new byte[3006];
		while(true)
		{
			// Read screen header (and write screen header)
			header = readScreenHeader(gis);
			if (header == null)
				break;
			if (header.length() > 20) // No header should realistically be this long
				throw new Exception("Unable to parse headers.");
			
			// Read screen data (will always be the next 3006 bytes)
			int bytesSoFar = 0;
			while (bytesSoFar < 3006)
			{
				int bytesRead = gis.read(screenData, bytesSoFar, 3006 - bytesSoFar);
				if (bytesRead == -1)
					throw new Exception("Unexpected end of file.");
				bytesSoFar += bytesRead;
			}
			
			// Package information into screen
			Screen s = new Screen(header, screenData);
			screens.add(s);
		}
		
		// Close resources
		bis.close();
		is.close();
		gis.close();
	}
	
	public void saveToFile(Path mapFile) throws IOException
	{
		// Setup GZip for map writing
		OutputStream os = Files.newOutputStream(mapFile);
		GZIPOutputStream gos = new GZIPOutputStream(os);
		
		// Write data one screen at a time
		for (Screen screen : screens)
			screen.writeTo(gos);
		
		// Finalize
		gos.close();
	}
	
	/**
	 * Uses the true random algorithm
	 */
	public void randomize(RandoKey randoKey, Random rand)
	{
		for(Screen s : screens)
			s.randomize(randoKey, rand);
	}
	
	/**
	 * Uses the transform algorithm
	 */
	public void randomize(RandoKey randoKey)
	{
		for(Screen s : screens)
			s.randomize(randoKey);
	}
	
	public void printScreens()
	{
		for(Screen s : screens)
			s.println();
	}

	public ObjectClass allObjects()
	{
		ObjectClass objects = new ObjectClass('.', null);
		for(Screen s : screens)
			s.collectObjects(objects);
		return objects;
	}
	
	public void populateShuffle(ObjectShuffle shuffle)
	{
		for(Screen s : screens)
			s.populateShuffle(shuffle);
	}
	
	public void shuffle(ObjectShuffle shuffle)
	{
		for(Screen s : screens)
			s.shuffle(shuffle);
	}
	
	public void randomizeMusic(Random rand)
	{
		// Collect music
		ArrayList<Byte> musics = new ArrayList<Byte>();
		for(Screen s : screens)
		{
			Byte music = s.getMusic();
			if (music != 0 && !musics.contains(music))
				musics.add(music);
		}
		
		// Create randomization hashmap
		ArrayList<Byte> remainingMusics = (ArrayList<Byte>) musics.clone();
		int numRemaining = remainingMusics.size();
		Map<Byte, Byte> musicRando = new HashMap<Byte, Byte>();
		for (Byte music : musics)
		{
			int i = rand.nextInt(numRemaining);
			musicRando.put(music, remainingMusics.remove(i));
			numRemaining--;
		}
		
		// Randomize the music
		for(Screen s : screens)
		{
			Byte key = s.getMusic();
			Byte value = musicRando.get(key);
			if (value == null)
				continue;
			s.setMusic(value);
		}
	}
}
