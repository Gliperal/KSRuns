import java.util.ArrayList;

public class ItemUtil
{
	public static final int numItems = Item.values().length;
	private static final Item[] items = Item.values();
	
	public static int indexOfItem(Item item)
	{
		for (int index = 0; index < numItems; index++)
			if (items[index].equals(item))
				return index;
		return -1;
	}
	
	public static Item itemFromIndex(int index)
	{
		return items[index];
	}
	
	public static ArrayList<Item> allItems()
	{
		ArrayList<Item> allItems = new ArrayList<Item>();
		for(Item i : Item.values())
			allItems.add(i);
		return allItems;
	}

	public static Item[] itemListToArray(ArrayList<Item> list)
	{
		int n = list.size();
		Item[] returnArray = new Item[n];
		for (int i = 0; i < n; i++)
			returnArray[i] = list.get(i);
		return returnArray;
	}
}
