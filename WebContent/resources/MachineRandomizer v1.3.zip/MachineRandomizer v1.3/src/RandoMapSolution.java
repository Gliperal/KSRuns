import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

public class RandoMapSolution
{
	private ArrayList<Item> importantItems;
	private ArrayList<Item> locationSequence;
	private ArrayList<Item> itemSequence;
	
	public RandoMapSolution(ArrayList<Item> importantItems, ArrayList<Item> locationSequence, ArrayList<Item> itemSequence)
	{
		this.importantItems = importantItems;
		this.locationSequence = locationSequence;
		this.itemSequence = itemSequence;
	}
	
	public void printTo(PrintWriter out)
	{
		Iterator<Item> locIt = locationSequence.iterator();
		Iterator<Item> itemIt = itemSequence.iterator();
		out.println("One possible item sequence:");
		while(locIt.hasNext())
		{
			Item nextItem = itemIt.next();
			Item nextLoc = locIt.next();
			if (importantItems.contains(nextItem))
				out.println("\t" + nextItem + " (located where " + nextLoc + " usually is)");
		}
	}
}
