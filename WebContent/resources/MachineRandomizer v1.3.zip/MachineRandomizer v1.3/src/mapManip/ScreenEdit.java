package mapManip;

public class ScreenEdit implements Edit
{
	private int type;
	private String screen;
	private int tileX;
	private int tileY;
	private int layer;
	private byte bank;
	private byte object;
	private byte tileset;
	private byte tile;
	
	private ScreenEdit() {}
	
	public static ScreenEdit addTile(EditLocation loc, int layer, int tile)
	{
		// TODO
		return null;
	}
	
	public static ScreenEdit addTile(EditLocation loc, int layer, int tileset, int tile)
	{
		ScreenEdit edit = new ScreenEdit();
		edit.type = 1;
		edit.screen = loc.screen;
		edit.layer = layer;
		edit.tileX = loc.tileX;
		edit.tileY = loc.tileY;
		edit.tileset = (byte) tileset;
		edit.tile = (byte) tile;
		return edit;
	}
	
	public static ScreenEdit addObject(EditLocation loc, int layer, int bank, int object)
	{
		ScreenEdit edit = new ScreenEdit();
		edit.type = 2;
		edit.screen = loc.screen;
		edit.layer = layer;
		edit.tileX = loc.tileX;
		edit.tileY = loc.tileY;
		edit.bank = (byte) bank;
		edit.object = (byte) object;
		return edit;
	}
	
	public boolean isForScreen(String screenHeader)
	{
		return screenHeader.equals(screen);
	}
	
	public void performEdit(byte[] screenData)
	{
		switch(type)
		{
		case 1:
			// Check if we have a tileset available.
			byte tilesetA = screenData[3000];
			byte tilesetB = screenData[3001];
			byte tileIndex;
			if (tilesetA == tileset)
				// Use tileset A
				tileIndex = tile;
			else if (tilesetB == tileset)
				// Use tileset B
				tileIndex = (byte) (tile + 128);
			else if (tilesetA == 0)
			{
				// Set tileset A and use that
				screenData[3000] = tileset;
				tileIndex = tile;
			}
			else if (tilesetB == 0)
			{
				// Set tileset B and use that
				screenData[3001] = tileset;
				tileIndex = (byte) (tile + 128);
			}
			else
				// No good tilesets to use
				break;
			// Write tile
			screenData[layer*250 + tileY*25 + tileX] = tileIndex;
			break;
		case 2:
			int objectBase = layer*500 - 1000;
			int bankBase = layer*500 - 750;
			int offset = tileY*25 + tileX;
			screenData[objectBase + offset] = object;
			screenData[bankBase + offset] = bank;
			break;
		}
	}
}
