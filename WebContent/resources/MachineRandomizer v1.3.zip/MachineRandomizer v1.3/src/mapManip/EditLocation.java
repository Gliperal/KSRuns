package mapManip;

public class EditLocation
{
	public String screen;
	public int tileX;
	public int tileY;
	
	public EditLocation(String screen, int tileX, int tileY)
	{
		this.screen = screen;
		this.tileX = tileX;
		this.tileY = tileY;
	}
}
