package mapManip;

public interface Edit {}
