package mapManip;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.io.IOUtils;

public class MapUtil
{
	// The byte sequence 0 -66 11 0 0 denotes end of header
	private static final String endOfHeader = "\u0000\uFFBE\u000B\u0000\u0000";
	
	private static String readScreenHeader(GZIPInputStream gis, GZIPOutputStream gos) throws IOException
	{
		byte[] buffer = new byte[1];
		int bytesRead;
		String header = "";
		while (true)
		{
			bytesRead = gis.read(buffer);
			if (bytesRead == -1)
				return null;
			header += (char) buffer[0];
			gos.write(buffer, 0, bytesRead);
			if (header.endsWith(endOfHeader))
				break;
			if (header.length() > 20)
				return null;
		}
		return header.substring(0, header.length() - 5);
	}
	
	public static int processMapFile(ArrayList<ScreenEdit> edits)
	{
		System.out.println("Editing map file...");
		try
		{
			// Setup GZip for map reading
			File fin = new File("resources/Map.bin");
			if (!fin.exists())
			{
				System.out.println("Could not find resources/Map.bin");
				return 1;
			}
			InputStream is = new FileInputStream(fin);
			byte[] ba = IOUtils.toByteArray(is);
			ByteArrayInputStream bis = new ByteArrayInputStream(ba);
			GZIPInputStream gis = new GZIPInputStream(bis);
			
			// Setup GZip for map writing
			File fout = new File("Map.bin");
			OutputStream os = new FileOutputStream(fout);
			GZIPOutputStream gos = new GZIPOutputStream(os);
			
			String header;
			byte[] screenData = new byte[3006];
			int screensProcessed = 0;
			while(true)
			{
				// Read screen header (and write screen header)
				header = readScreenHeader(gis, gos);
				if (header == null)
					break;
				
				// Read screen data (will always be the next 3006 bytes)
				int bytesRead = 0;
				while (bytesRead < 3006)
				{
					bytesRead += gis.read(screenData, bytesRead, 3006 - bytesRead);
					if (bytesRead == -1)
						break; // TODO Something went wrong if this happens
				}
				
				// Perform edits
				for (ScreenEdit edit : edits)
					if (edit.isForScreen(header))
						edit.performEdit(screenData);
				
				// Write new screen data
				gos.write(screenData, 0, 3006);
				
				// Output progress
				screensProcessed++;
				if (screensProcessed % 55 == 0)
					System.out.print(screensProcessed/55 + "0%...");
			}
			System.out.println("100%");
			
			byte[] buffer = new byte[1024];
			int bytesRead;
			while((bytesRead = gis.read(buffer)) != -1)
			{
				gos.write(buffer, 0, bytesRead);
			}
			gos.close();
		}
		catch (IOException e)
		{
			System.out.println("IOException");
			e.printStackTrace();
			return 1;
		}
		System.out.println("Success.");
		return 0;
	}
	
	public static int processWorldFile(ArrayList<WorldEdit> edits)
	{
		System.out.println("Editing World INI...");
		BufferedReader br;
		PrintWriter pw;
		
		File fin = new File("resources/World.ini");
		if (!fin.exists())
		{
			System.out.println("Could not find resources/World.ini");
			return 1;
		}
		File fout = new File("World.ini");
		try
		{
			br = new BufferedReader(new FileReader(fin));
			pw = new PrintWriter(fout);
			String line;
			while((line = br.readLine()) != null)
			{
				for (WorldEdit edit : edits)
					line = edit.performEdit(line);
				pw.println(line);
			}
			br.close();
			pw.close();
		} catch (IOException e)
		{
			System.out.println("IOException");
			return 1;
		}
		System.out.println("Success.");
		return 0;
	}
}
