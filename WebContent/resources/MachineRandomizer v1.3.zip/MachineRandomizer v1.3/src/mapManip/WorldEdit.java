package mapManip;

public class WorldEdit implements Edit
{
	private String key;
	private String replace;
	
	public WorldEdit(String pattern, String replacement)
	{
		key = pattern;
		replace = replacement;
	}
	
	public String performEdit(String data)
	{
		return data.replaceAll(key, replace);
	}
}
