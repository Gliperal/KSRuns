import java.util.ArrayList;

import mapManip.EditLocation;
import mapManip.ScreenEdit;
import mapManip.WorldEdit;

public class TheMachine implements LevelData
{
	private TheMachineFlags flags;
	
	public TheMachine(TheMachineFlags flags)
	{
		this.flags = flags;
	}
	
	@Override
	public Requisites getItemRequirements()
	{
		Requisites reqs = new Requisites();
		
		// Start area
		reqs.add(new Requisite(Item.Run));
		reqs.add(new Requisite(Item.Climb));
		reqs.add(new Requisite(Item.DJ, Item.Run, Item.Climb));
		if (!flags.modeSafe && flags.trickyJumps)
		{
			reqs.add(new Requisite(Item.DJ, Item.Difficulty, Item.Climb, Item.DJ));
			reqs.add(new Requisite(Item.DJ, Item.Difficulty, Item.Climb, Item.Umbrella));
		}
		reqs.add(new Requisite(Item.HJ, Item.Climb, Item.Run));
		reqs.add(new Requisite(Item.HJ, Item.Climb, Item.DJ));
		reqs.add(new Requisite(Item.HJ, Item.Climb, Item.HJ));
		reqs.add(new Requisite(Item.HJ, Item.Climb, Item.Umbrella));
		reqs.add(new Requisite(Item.Detector, Item.Climb, Item.Run));
		reqs.add(new Requisite(Item.Detector, Item.Climb, Item.DJ));
		reqs.add(new Requisite(Item.Detector, Item.Climb, Item.HJ));
		reqs.add(new Requisite(Item.Detector, Item.Climb, Item.Umbrella));
		reqs.add(new Requisite(Item.Detector, Item.DJ, Item.HJ));
		reqs.add(new Requisite(Item.Purple, Item.Run, Item.Climb, Item.DJ, Item.HJ, Item.Umbrella));
		reqs.add(new Requisite(Item.Difficulty));
		
		// Left side
		reqs.add(new Requisite(Item.LeftSide, Item.Climb, Item.Run, Item.DJ));
		reqs.add(new Requisite(Item.LeftSide, Item.Climb, Item.Run, Item.HJ));
		reqs.add(new Requisite(Item.LeftSide, Item.Climb, Item.Run, Item.Umbrella));
		reqs.add(new Requisite(Item.LeftSide, Item.Climb, Item.DJ, Item.HJ));
		reqs.add(new Requisite(Item.LeftSide, Item.Climb, Item.DJ, Item.Umbrella));
		reqs.add(new Requisite(Item.LeftSide, Item.Climb, Item.HJ, Item.Umbrella));
		reqs.add(new Requisite(Item.Henna, Item.LeftSide));
		// Switch
		reqs.add(new Requisite(Item.Switch, Item.LeftSide, Item.Hologram, Item.DJ, Item.Run, Item.HJ));
		reqs.add(new Requisite(Item.Switch, Item.LeftSide, Item.Hologram, Item.DJ, Item.Run, Item.Umbrella));
		reqs.add(new Requisite(Item.Switch, Item.LeftSide, Item.Hologram, Item.DJ, Item.HJ, Item.Umbrella));
		reqs.add(new Requisite(Item.Red, Item.Switch, Item.Climb, Item.Run, Item.DJ, Item.HJ));
		reqs.add(new Requisite(Item.Red, Item.Switch, Item.Climb, Item.Run, Item.DJ, Item.Umbrella));
		reqs.add(new Requisite(Item.Red, Item.Switch, Item.Climb, Item.Run, Item.HJ, Item.Umbrella));
		reqs.add(new Requisite(Item.Red, Item.Switch, Item.Climb, Item.DJ, Item.HJ, Item.Umbrella));
		
		// Right side
		reqs.add(new Requisite(Item.RightSide, Item.Climb, Item.DJ, Item.HJ));
		if (flags.trickyJumps)
		{
			reqs.add(new Requisite(Item.RightSide, Item.Climb, Item.DJ, Item.Run, Item.Umbrella));
			reqs.add(new Requisite(Item.RightSide, Item.Climb, Item.DJ, Item.Run));
		}
		reqs.add(new Requisite(Item.Eye, Item.RightSide));
		reqs.add(new Requisite(Item.Umbrella, Item.RightSide, Item.Eye));
		if (!flags.modeSafe)
			reqs.add(new Requisite(Item.Umbrella, Item.RightSide, Item.Run, Item.HJ, Item.Umbrella, Item.Difficulty));
		reqs.add(new Requisite(Item.Hologram, Item.RightSide, Item.Umbrella));
		reqs.add(new Requisite(Item.Yellow, Item.RightSide, Item.Umbrella));
		if (flags.trickyJumps)
			reqs.add(new Requisite(Item.Blue, Item.RightSide));
		else
			reqs.add(new Requisite(Item.Blue, Item.RightSide, Item.HJ));
		
		return reqs;
	}
	
	@Override
	public Requisites getItemExitRequirements()
	{
		Requisites exitReqs = new Requisites();
		exitReqs.add(new Requisite(Item.Run));
		exitReqs.add(new Requisite(Item.Climb, Item.Climb, Item.Run));
		exitReqs.add(new Requisite(Item.Climb, Item.Climb, Item.DJ));
		exitReqs.add(new Requisite(Item.Climb, Item.Climb, Item.HJ));
		exitReqs.add(new Requisite(Item.Climb, Item.Climb, Item.Umbrella));
		exitReqs.add(new Requisite(Item.Climb, Item.DJ, Item.HJ));
		exitReqs.add(new Requisite(Item.DJ));
		exitReqs.add(new Requisite(Item.HJ));
		exitReqs.add(new Requisite(Item.Eye, Item.Run));
		exitReqs.add(new Requisite(Item.Eye, Item.Hologram));
		exitReqs.add(new Requisite(Item.Eye, Item.Difficulty));
		exitReqs.add(new Requisite(Item.Detector, Item.Climb));
		exitReqs.add(new Requisite(Item.Umbrella));
		exitReqs.add(new Requisite(Item.Hologram, Item.Hologram));
		exitReqs.add(new Requisite(Item.Red));
		exitReqs.add(new Requisite(Item.Yellow));
		exitReqs.add(new Requisite(Item.Blue));
		exitReqs.add(new Requisite(Item.Purple));
		exitReqs.add(new Requisite(Item.LeftSide));
		exitReqs.add(new Requisite(Item.RightSide));
		exitReqs.add(new Requisite(Item.Henna));
		exitReqs.add(new Requisite(Item.Switch, Item.Switch));
		exitReqs.add(new Requisite(Item.Switch, Item.HJ));
		exitReqs.add(new Requisite(Item.Difficulty));
		return exitReqs;
	}
	
	public ArrayList<Item> keyItems()
	{
		ArrayList<Item> randoItems = new ArrayList<Item>();
		if (!flags.earlyRun)
			randoItems.add(Item.Run);
		randoItems.add(Item.Climb);
		randoItems.add(Item.DJ);
		randoItems.add(Item.HJ);
		randoItems.add(Item.Eye);
		randoItems.add(Item.Detector);
		randoItems.add(Item.Umbrella);
		randoItems.add(Item.Hologram);
		randoItems.add(Item.Red);
		randoItems.add(Item.Yellow);
		randoItems.add(Item.Blue);
		randoItems.add(Item.Purple);
		if (flags.memeItems)
		{
			randoItems.add(Item.Henna);
			randoItems.add(Item.Switch);
			randoItems.add(Item.Difficulty);
		}
		return randoItems;
	}
	
	public EditLocation[] itemLocations(Item item)
	{
		switch(item)
		{
		case Run:
			return new EditLocation[]
			{
					new EditLocation("x1000y1000", 12, 8),
					new EditLocation("x1000y1020", 12, 8),
					new EditLocation("x996y1002", 11, 8),
					new EditLocation("x996y1022", 18, 8)
			};
		case Climb:
			return new EditLocation[]
			{
					new EditLocation("x996y1002", 8, 8),
					new EditLocation("x996y1022", 8, 8)
			};
		case DJ:
			return new EditLocation[]
			{
					new EditLocation("x999y999", 16, 4),
					new EditLocation("x999y1019", 16, 4)
			};
		case HJ:
			return new EditLocation[]
			{
					new EditLocation("x1010y997", 23, 3),
					new EditLocation("x1010y1017", 23, 3)
			};
		case Eye:
			return new EditLocation[]
			{
					new EditLocation("x1028y1002", 13, 8),
					new EditLocation("x1028y1022", 13, 8)
			};
		case Detector:
			return new EditLocation[]
			{
					new EditLocation("x997y1002", 11, 7),
					new EditLocation("x997y1022", 11, 7)
			};
		case Umbrella:
			return new EditLocation[]
			{
					new EditLocation("x1040y1001", 19, 8),
					new EditLocation("x1040y1021", 19, 8)
			};
		case Hologram:
			return new EditLocation[]
			{
					new EditLocation("x1023y1000", 3, 5),
					new EditLocation("x1023y1020", 3, 5)
			};
		case Red:
			return new EditLocation[]
			{
					new EditLocation("x1002y989", 23, 8),
					new EditLocation("x1002y1009", 23, 8)
			};
		case Yellow:
			return new EditLocation[]
			{
					new EditLocation("x1024y993", 22, 7),
					new EditLocation("x1024y1013", 22, 7)
			};
		case Blue:
			return new EditLocation[]
			{
					new EditLocation("x1017y993", 12, 7),
					new EditLocation("x1017y1013", 12, 7)
			};
		case Purple:
			return new EditLocation[]
			{
					new EditLocation("x999y996", 3, 2),
					new EditLocation("x999y1016", 3, 2)
			};
		case Difficulty:
			return new EditLocation[]
			{
					new EditLocation("x999y1000", 11, 8),
					new EditLocation("x999y1020", 11, 8)
			};
		case Switch:
			return new EditLocation[]
			{
					new EditLocation("x980y1007", 8, 8),
					new EditLocation("x980y1027", 8, 8),
			};
		case Henna:
			return new EditLocation[]
			{
					new EditLocation("x985y1001", 14, 7),
					new EditLocation("x985y1021", 14, 7)
			};
		default:
			return null;
		}
	}
	
	@Override
	public void addEdits(Item oldItem, Item replacement, ArrayList<ScreenEdit> screenEdits, ArrayList<WorldEdit> worldEdits)
	{
		EditLocation[] editLocs = itemLocations(oldItem);
		switch(replacement)
		{
		case Run:
			for (EditLocation loc : editLocs)
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 3));
			break;
		case Climb:
			for (EditLocation loc : editLocs)
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 4));
			break;
		case DJ:
			for (EditLocation loc : editLocs)
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 5));
			break;
		case HJ:
			for (EditLocation loc : editLocs)
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 6));
			break;
		case Eye:
			for (EditLocation loc : editLocs)
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 7));
			break;
		case Detector:
			for (EditLocation loc : editLocs)
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 8));
			break;
		case Umbrella:
			for (EditLocation loc : editLocs)
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 9));
			break;
		case Hologram:
			for (EditLocation loc : editLocs)
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 10));
			break;
		case Red:
			for (EditLocation loc : editLocs)
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 21));
			break;
		case Yellow:
			for (EditLocation loc : editLocs)
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 22));
			break;
		case Blue:
			for (EditLocation loc : editLocs)
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 23));
			break;
		case Purple:
			for (EditLocation loc : editLocs)
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 24));
			break;
		case Henna:
			for (int i = 0; i < editLocs.length; i++)
			{
				EditLocation loc = editLocs[i];
				screenEdits.add(ScreenEdit.addObject(loc, 4, 3, 41));
				screenEdits.add(ScreenEdit.addObject(loc, 5, 0, 17));
				if (i % 2 == 0)
					// Easy mode
					worldEdits.add(new WorldEdit("=HENNA_E=", loc.screen));
				else
					// Normal mode
					worldEdits.add(new WorldEdit("=HENNA_N=", loc.screen));
			}
			break;
		case Switch:
			for (int i = 0; i < editLocs.length; i++)
			{
				EditLocation loc = editLocs[i];
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 14));
				screenEdits.add(ScreenEdit.addObject(loc, 5, 0, 17));
				screenEdits.add(ScreenEdit.addTile(loc, 2, 28, 29));
				if (i % 2 == 0)
					// Easy mode
					worldEdits.add(new WorldEdit("=SWITCH_E=", loc.screen));
				else
					// Normal mode
					worldEdits.add(new WorldEdit("=SWITCH_N=", loc.screen));
			}
			break;
		case Difficulty:
			for (int i = 0; i < editLocs.length; i++)
			{
				EditLocation loc = editLocs[i];
				screenEdits.add(ScreenEdit.addObject(loc, 4, 0, 14));
				screenEdits.add(ScreenEdit.addObject(loc, 5, 0, 17));
				if (i % 2 == 0)
				{
					// Easy mode
					screenEdits.add(ScreenEdit.addTile(loc, 2, 9, 101));
					worldEdits.add(new WorldEdit("=DIFFICULTY_E=", loc.screen));
				}
				else
				{
					// Normal mode
					screenEdits.add(ScreenEdit.addTile(loc, 2, 9, 85));
					worldEdits.add(new WorldEdit("=DIFFICULTY_N=", loc.screen));
				}
			}
			break;
		default:
			break;
		}
	}
}
