
public class Requisite
{
	private Item keyItem;
	private boolean[] itemNeeds;
	
	public Requisite(Item keyItem, Item ... requiredItems)
	{
		this.keyItem = keyItem;
		itemNeeds = new boolean[ItemUtil.numItems];
		for (int i = 0; i < ItemUtil.numItems; i++)
			itemNeeds[i] = listContains(requiredItems, ItemUtil.itemFromIndex(i));
	}
	
	private boolean listContains(Item[] list, Item i)
	{
		for (Item l : list)
			if (l.equals(i))
				return true;
		return false;
	}
	
	public Item getKeyItem()
	{
		return keyItem;
	}
	
	public boolean matches(boolean[] currentItems)
	{
		for (int i = 0; i < ItemUtil.numItems; i++)
			if (itemNeeds[i] && !currentItems[i])
				return false;
		return true;
	}
}
