import java.io.PrintWriter;

public class TheMachineFlags
{
	public boolean modeSafe;
	public boolean memeItems;
	public boolean earlyRun;
	public boolean trickyJumps;
	
	public TheMachineFlags(boolean modeSafe, boolean memeItems, boolean earlyRun, boolean trickyJumps)
	{
		this.modeSafe = modeSafe;
		this.memeItems = memeItems;
		this.earlyRun = earlyRun;
		this.trickyJumps = trickyJumps;
	}

	public void printTo(PrintWriter out)
	{
		out.println("Flags");
		out.println("\tEnsure playability on Normal\t" + modeSafe);
		out.println("\tInlucde meme items\t\t" + memeItems);
		out.println("\tEliminate trickjumps\t\t" + !trickyJumps);
		out.println("\tDefault Run location\t\t" + earlyRun);
	}
}
