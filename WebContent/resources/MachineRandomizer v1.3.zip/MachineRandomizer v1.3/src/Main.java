import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Random;
import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		// Get user input
		Scanner input = new Scanner(System.in);
		// Safe to play on just hard mode and never switch
		boolean modeSafe = getBooleanInput(input, "Ensure the map can be beaten without using Easy mode? [Y/N]");
		boolean includeMemes = getBooleanInput(input, "Include meme items? [Y/N]");
		boolean includeTrickjumps = !getBooleanInput(input, "Restrict the difficulty of required jumps? [Y/N]");
		boolean earlyRun = getBooleanInput(input, "Force Run powerup to not be randomized? [Y/N]");
		boolean normalMode =
				includeMemes ?
						getBooleanInput(input, "Start on Normal mode instead of Easy? [Y/N]")
				:
						!modeSafe;
		long mapSeed = getSeedInput(input, "Enter seed or leave blank for random.");
		
		// Generate level data
		TheMachineFlags machineFlags = new TheMachineFlags(modeSafe, includeMemes, earlyRun, includeTrickjumps);
		LevelData machine = new TheMachine(machineFlags);
		
		// Test maps for viability until we find one that works
		System.out.print("Randomizing");
		RandoMap map = null;
		RandoMapSolution solution = null;
		while (true)
		{
			// Generate a new random item distribution.
			map = new RandoMap(machine, mapSeed);
			
			// Test if the map is completable
			solution = map.solve();
			
			// If the seed didn't work, add 1 and try again.
			if (solution == null)
			{
				mapSeed++;
				System.out.print(".");
				continue;
			}
			break;
		}
		System.out.println();
		
		// Create extra stuff
		int result = map.createMap();
		if (result == 0)
		{
			// Create savegame file
			File savegameSrc;
			File savegameDest = new File("DefaultSavegame.ini");
			if (normalMode)
				savegameSrc = new File("resources/DefaultSavegameB.ini");
			else
				savegameSrc = new File("resources/DefaultSavegameA.ini");
			try
			{
				Files.copy(savegameSrc.toPath(), savegameDest.toPath(), StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException e) {}
			
			// Create spoiler file
			try
			{
				File spoiler = new File("spoiler.txt");
				PrintWriter out = new PrintWriter(spoiler);
				// Add the flag information
				machineFlags.printTo(out);
				out.println();
				// Add the seed
				out.println("Seed m" + mapSeed);
				out.println();
				// Add the map
				map.printTo(out);
				out.println();
				// Add the solution
				solution.printTo(out);
				// Close file
				out.close();
			} catch (IOException e)
			{
				System.out.println("Error creating spoiler file.");
			}
		}
		System.out.println("Press Enter to exit.");
		input.nextLine();
		input.close();
	}
	
	public static boolean getBooleanInput(Scanner input, String prompt)
	{
		while (true)
		{
			System.out.println(prompt);
			switch(input.nextLine().toLowerCase())
			{
			case "y":
			case "yes":
				return true;
			case "n":
			case "no":
				return false;
			default:
				System.out.println("Please respond with either Y or N.");
				continue;
			}
		}
	}

	public static long getSeedInput(Scanner input, String prompt)
	{
		// Get user input
		System.out.println(prompt);
		String rawSeed = input.nextLine();
		
		// Empty string is a truly pseudorandom seed (using the system clock)
		if (rawSeed.equals(""))
			return System.nanoTime();
		
		// String of the form m###### is a raw seed
		if (rawSeed.charAt(0) == 'm')
		{
			try
			{
				return Long.parseLong(rawSeed.substring(1, rawSeed.length()));
			}
			catch (NumberFormatException e) {}
		}
		
		// Convert string seed into a long
		long seed = 0;
		for (char c : rawSeed.toCharArray())
		{
			seed *= 127;
			seed += c;
		}
		
		// Generate a seed for the map based on the user's seed.
		Random rand = new Random(seed);
		long mapSeed = rand.nextLong();
		return mapSeed;
	}
	
	
	
	
	
	
	
	// This function searches for a seed matching a specific very difficult item arrangement
	// Ideally I'd change this so that you get the switch at blue key, and that takes you to high jump @ red key
	
	public static void hardThing()
	{
		TheMachineFlags machineFlags = new TheMachineFlags(false, true, false, true);
		LevelData machine = new TheMachine(machineFlags);
		RandoMap map = null;
		RandoMapSolution solution = null;
		//int mapSeed = -1000000;
		int mapSeed = 10611506;
		while (true)
		{
			// Generate a new random item distribution.
			map = new RandoMap(machine, mapSeed);
			
			// Test if the map is completable
			solution = map.solve();
			
			// If the seed didn't work, add 1 and try again.
			if (solution == null)
			{
				mapSeed++;
				continue;
			}
			
			// ~~~~~~~~~~~
			int count = 0;
			if (map.itemAtLocation(Item.Run) == Item.Climb)
				count++;
			if (map.itemAtLocation(Item.Run) == Item.Umbrella)
				count++;
			if (map.itemAtLocation(Item.Difficulty) == Item.Climb)
				count++;
			if (map.itemAtLocation(Item.Difficulty) == Item.Umbrella)
				count++;
			if (map.itemAtLocation(Item.Climb) == Item.Climb)
				count++;
			if (map.itemAtLocation(Item.Climb) == Item.Umbrella)
				count++;
			if (map.itemAtLocation(Item.Detector) == Item.Difficulty)
				count++;
			if (map.itemAtLocation(Item.DJ) == Item.Run)
				count++;
			if (map.itemAtLocation(Item.DJ) == Item.DJ)
				count++;
			if (map.itemAtLocation(Item.Henna) == Item.Run)
				count++;
			if (map.itemAtLocation(Item.Henna) == Item.DJ)
				count++;
			if (map.itemAtLocation(Item.Blue) == Item.HJ)
				count++;
			if (map.itemAtLocation(Item.Blue) == Item.Switch && map.itemAtLocation(Item.Red) == Item.HJ)
				count++;
			if (map.itemAtLocation(Item.Umbrella) == Item.Hologram)
				count++;
			if (map.itemAtLocation(Item.Hologram) == Item.Eye)
				count++;
			if (map.itemAtLocation(Item.Switch) == Item.Eye)
				count++;
			if (count > 2)
				System.out.println(mapSeed + "\t" + count);
			if (count < 8)
			{
				mapSeed++;
				continue;
			}
			break;
		}
		System.out.println();
		try
		{
			File spoiler = new File("spoiler.txt");
			PrintWriter out = new PrintWriter(spoiler);
			solution.printTo(out);
			out.close();
		} catch (FileNotFoundException e) {}
	}
}
