import java.util.ArrayList;

public class Requisites
{
	private ArrayList<Requisite> list;
	
	public Requisites()
	{
		list = new ArrayList<Requisite>();
	}
	
	public void add(Requisite r)
	{
		list.add(r);
	}

	public ArrayList<Item> nextAvailableItems(boolean[] currentItems)
	{
		ArrayList<Item> results = new ArrayList<Item>();
		for (Requisite r : list)
		{
			Item nextItem = r.getKeyItem();
			if (r.matches(currentItems) && !results.contains(nextItem))
				results.add(nextItem);
		}
		return results;
	}

	public boolean canReachItem(Item desiredItem, boolean[] currentItems)
	{
		for (Requisite r : list)
		{
			if (r.getKeyItem() != desiredItem)
				continue;
			if (r.matches(currentItems))
				return true;
		}
		return false;
	}
}
