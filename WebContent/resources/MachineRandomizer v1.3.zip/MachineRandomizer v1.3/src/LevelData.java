import java.util.ArrayList;

import mapManip.EditLocation;
import mapManip.ScreenEdit;
import mapManip.WorldEdit;

public interface LevelData
{
	// Get a list of all the items that are going to be randomized
	public ArrayList<Item> keyItems();
	// Get an object describing the items that are required to reach any given item location
	public Requisites getItemRequirements();
	// Get an object describing the items that are required to leave any given item location
	public Requisites getItemExitRequirements();
	// Retrieve a list of all the locations in the level where an item can be found
	public EditLocation[] itemLocations(Item item);
	// Add the edits that are required for the level in order for oldItem to be replaced by newItem
	public void addEdits(Item oldItem, Item newItem, ArrayList<ScreenEdit> screenEdits, ArrayList<WorldEdit> worldEdits);
}
