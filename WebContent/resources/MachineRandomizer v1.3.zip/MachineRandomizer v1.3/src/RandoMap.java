import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;

import mapManip.*;

public class RandoMap
{
	private LevelData level;
	private Item[] locations;
	private Item[] items;
	private int numItems;
	
	public RandoMap(LevelData level, long seed)
	{
		this.level = level;
		ArrayList<Item> remainingItems = level.keyItems();
		locations = ItemUtil.itemListToArray(remainingItems);
		numItems = locations.length;
		items = new Item[ItemUtil.numItems];
		
		Random rand = new Random(seed);
		for (int i = 0; i < numItems; i++)
		{
			int nextItem = rand.nextInt(numItems - i);
			items[i] = remainingItems.remove(nextItem);
		}
	}
	
	public Item itemAtLocation(Item location)
	{
		for (int i = 0; i < numItems; i++)
			if (locations[i].equals(location))
				return items[i];
		// If it's not one of the randomized items
		return location;
	}
	
	public RandoMapSolution solve()
	{
		// Get reqs info (required items to get to item locations)
		Requisites reqs = level.getItemRequirements();
		
		// Get exit reqs info (required items to leave from item locations)
		Requisites exitReqs = level.getItemExitRequirements();
		
		// Initialize items (when we start we don't have any)
		boolean[] currentItems = new boolean[ItemUtil.numItems];
		for(int i = 0; i < ItemUtil.numItems; i++)
			currentItems[i] = false;
		
		// Reset item sequence
		ArrayList<Item> locationSequence = new ArrayList<Item>();
		ArrayList<Item> itemSequence = new ArrayList<Item>();
		
		// Run around the map until we can find no more items to collect
		boolean newItemsFound = true;
		while (newItemsFound)
		{
			newItemsFound = false;
			// See what locations/items are available
			ArrayList<Item> openLocations = reqs.nextAvailableItems(currentItems);
			for (Item location : openLocations)
			{
				Item nextItem = itemAtLocation(location);
				// If it's an item that we haven't already found...
				if (!currentItems[ItemUtil.indexOfItem(nextItem)])
				{
					currentItems[ItemUtil.indexOfItem(nextItem)] = true;
					// Make sure we can safely escape after grabbing it
					if (exitReqs.canReachItem(location, currentItems))
					{
						newItemsFound = true;
						locationSequence.add(location);
						itemSequence.add(nextItem);
					}
					else
						currentItems[ItemUtil.indexOfItem(nextItem)] = false;
				}
			}
		}
		
		// If we're still missing items, this map cannot be completed (at least not 100%)
		for (boolean item : currentItems)
			if (!item)
				return null;
		
		// If we're not missing items, return the successful sequence
		return new RandoMapSolution(level.keyItems(), locationSequence, itemSequence);
	}
	
	public int createMap()
	{
		// Build ArrayLists of required edits
		System.out.println("Recording changes...");
		ArrayList<ScreenEdit> sEdits = new ArrayList<ScreenEdit>();
		ArrayList<WorldEdit> wEdits = new ArrayList<WorldEdit>();
		ArrayList<Item> unmovedItems = ItemUtil.allItems();
		for (int i = 0; i < numItems; i++)
		{
			level.addEdits(locations[i], items[i], sEdits, wEdits);
			unmovedItems.remove(locations[i]);
		}
		for(Item item : unmovedItems)
			level.addEdits(item, item, sEdits, wEdits);
		
		// Edit the Map.bin file
		int result = MapUtil.processMapFile(sEdits);
		if (result != 0)
		{
			System.out.println("Map creation failed.");
			return 1;
		}
		
		// Edit the World.ini file
		result = MapUtil.processWorldFile(wEdits);
		if (result != 0)
		{
			System.out.println("World INI failed.");
			return 1;
		}
		System.out.println("All files created successfully.");
		return 0;
	}
	
	public String toString()
	{
		String str = "RandoMap\n";
		for (int i = 0; i < numItems; i++)
			str += "\t" + locations[i] + " ==> " + items[i] + "\n";
		return str;
	}
	
	public void printTo(PrintWriter pw)
	{
		for (int i = 0; i < numItems; i++)
			pw.println(locations[i] + " ==> " + items[i]);
	}
}
